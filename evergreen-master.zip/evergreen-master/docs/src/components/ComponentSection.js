import React from 'react'

const ComponentSection = ({ ...props }) => (
  <section className="ComponentSection" {...props} />
)

export default ComponentSection
