export default path => {
  return `https://evergreen.segment.com${path || ''}`
}
