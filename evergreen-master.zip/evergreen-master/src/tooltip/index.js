export { default as Tooltip } from './src/Tooltip' // eslint-disable-line import/prefer-default-export
