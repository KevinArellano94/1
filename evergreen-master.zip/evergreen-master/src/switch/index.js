export { default as Switch } from './src/Switch' // eslint-disable-line import/prefer-default-export
