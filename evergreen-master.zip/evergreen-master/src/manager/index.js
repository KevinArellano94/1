export { default as Manager } from './src/Manager' // eslint-disable-line import/prefer-default-export
