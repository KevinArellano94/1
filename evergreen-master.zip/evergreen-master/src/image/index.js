export { default as Image } from './src/Image' // eslint-disable-line import/prefer-default-export
