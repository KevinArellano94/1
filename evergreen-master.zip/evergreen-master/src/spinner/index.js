export { default as Spinner } from './src/Spinner' // eslint-disable-line import/prefer-default-export
