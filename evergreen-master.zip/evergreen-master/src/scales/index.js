export { default as minorScale } from './src/minorScale'
export { default as majorScale } from './src/majorScale'
