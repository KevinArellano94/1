export { default as CornerDialog } from './src/CornerDialog' // eslint-disable-line import/prefer-default-export
