export { default as SearchInput } from './src/SearchInput' // eslint-disable-line import/prefer-default-export
