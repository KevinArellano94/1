export { default as headings } from './headings'
export { default as text } from './text'
export { default as fontFamilies } from './fontFamilies'
export { default as paragraph } from './paragraph'
