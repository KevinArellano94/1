import fills from '../foundational-styles/fills'

const avatarColors = fills.options

export default avatarColors
