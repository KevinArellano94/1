import fills from '../foundational-styles/fills'

const badgeColors = fills.options

export default badgeColors
