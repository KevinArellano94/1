import scales from '../foundational-styles/scales'

const spinnerColor = scales.neutral.N6A

export default spinnerColor
