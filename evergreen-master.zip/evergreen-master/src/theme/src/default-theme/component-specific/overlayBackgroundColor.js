import scales from '../foundational-styles/scales'

const overlayBackgroundColor = scales.neutral.N7A

export default overlayBackgroundColor
