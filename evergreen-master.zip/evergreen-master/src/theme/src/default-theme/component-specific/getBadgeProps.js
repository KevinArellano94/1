export { default } from './getAvatarProps'
