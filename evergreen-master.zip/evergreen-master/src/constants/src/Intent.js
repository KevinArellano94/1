export default {
  NONE: 'none',
  SUCCESS: 'success',
  WARNING: 'warning',
  DANGER: 'danger'
}
