export { default as toaster } from './src' // eslint-disable-line import/prefer-default-export
