import Toaster from './Toaster'

const toaster = new Toaster()

export default toaster
