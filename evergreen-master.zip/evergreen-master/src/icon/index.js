export { default as Icon, IconNames } from './src/Icon'
