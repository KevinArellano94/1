export { default as SegmentedControl } from './src/SegmentedControl' // eslint-disable-line import/prefer-default-export
