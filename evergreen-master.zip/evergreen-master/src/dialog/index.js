export { default as Dialog } from './src/Dialog' // eslint-disable-line import/prefer-default-export
