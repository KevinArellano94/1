export { default as Portal } from './src/Portal' // eslint-disable-line import/prefer-default-export
