export { default as FilePicker } from './src/FilePicker' // eslint-disable-line import/prefer-default-export
