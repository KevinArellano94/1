export { default as TagInput } from './src/TagInput' // eslint-disable-line import/prefer-default-export
