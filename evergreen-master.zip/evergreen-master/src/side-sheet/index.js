export { default as SideSheet } from './src/SideSheet' // eslint-disable-line import/prefer-default-export
