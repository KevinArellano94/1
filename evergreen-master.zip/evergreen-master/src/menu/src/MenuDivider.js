import React from 'react'
import { Pane } from '../../layers'

export default class MenuDivider extends React.PureComponent {
  render() {
    return <Pane borderBottom />
  }
}
