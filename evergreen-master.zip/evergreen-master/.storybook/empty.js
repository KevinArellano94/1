// This file exists to satisfy the `require('./requireStories!…')` call in
// `config.js`. It doesn't need to contain anything, it just has to exist.
