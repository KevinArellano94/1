/* eslint-disable import/no-unresolved */
import React from 'react'
import { Button } from 'evergreen-ui'

export default () => <Button>🌲</Button>
